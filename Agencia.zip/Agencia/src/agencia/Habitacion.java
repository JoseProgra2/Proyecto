/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agencia;

import java.time.LocalDate;

/**
 *
 * @author ESTUDIANTE
 */
public class Habitacion extends Alojamiento{
    private int MaxPerson;

    public Habitacion() {
        super();
    }

    public Habitacion(int MaxPerson, int codigo, String direccion, String ciudad, String pais) {
        super(codigo, direccion, ciudad, pais);
        this.MaxPerson = MaxPerson;
    }

    public int getMaxPerson() {
        return MaxPerson;
    }

    public void setMaxPerson(int MaxPerson) {
        this.MaxPerson = MaxPerson;
    }

    @Override
    public String toString() {
        return "Habitacion{" + "MaxPerson=" + MaxPerson + '}';
    }

    @Override
    public double liquidarPersonaDia() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public double cotizar(LocalDate IDate, LocalDate fDate) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
