/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestiondecotizaciones;
import java.util.Scanner;
import java.util.InputMismatchException;
/**
 *
 * @author ESTUDIANTE
 */
public class Ppal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner sn = new Scanner(System.in);
       boolean salir = false;
       int opcion;
       while(!salir){
           System.out.println("         Cotizacion");
           System.out.println("           ");
           System.out.println("            Menu:");
           System.out.println("1 - Realizar una cotización");
           System.out.println("2 - Consultar una cotización");
           System.out.println("3 - Modificar una cotización");
           System.out.println("4 - Eliminar una cotización");
           System.out.println("5 - Salir");
           System.out.println("                ");
          try{
           System.out.println("Digite una opcion segun lo que desea realizar:");
           opcion = sn.nextInt();
           switch(opcion){
               case 1 -> { 
                   System.out.println(" Registro de Cotizacion");
                   
                   break;
                   }
               case 2 -> { System.out.println("Consultar");
                   break;
                   }
               case 3 -> {System.out.println("Modificar cotizacion");
                   break;
                   }
               case 4 -> {System.out.println("");
                   break;
                   }
               case 5 -> { salir=true;
                   break;
                   }
               default -> System.out.println("Solo numeros del 1 al 5");     
           }
               
           }catch(InputMismatchException e){
               System.out.println("Debes insertar un numero");
               sn.next();
           }
       }
    }
    public void RealizarCotizacion(){
        
      
    }
}
