/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestiondecotizaciones;

/**
 *
 * @author Jose Lopez
 */
public class ProductoMedida extends Producto {
       private double precioPorMetro;
      private int metro;

    public ProductoMedida() {
        super();
    }

    public ProductoMedida(double precioPorMetro, int metro, int idProducto, String nombre, String descripcion, double precio, int cantidad, Inventario productoinventario) {
        super(idProducto, nombre, descripcion, precio, cantidad, productoinventario);
        this.precioPorMetro = precioPorMetro;
        this.metro = metro;
    }
      
    public double getPrecioPorMetro() {
        return precioPorMetro;
    }

    public void setPrecioPorMetro(double precioPorMetro) {
        this.precioPorMetro = precioPorMetro;
    }

    public int getMetro() {
        return metro;
    }

    public void setMetro(int metro) {
        this.metro = metro;
    }
     @Override
    public double calcularPrecio() {
        double precio=this.precioPorMetro*this.metro;
    return precio;
    }
}
