/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestiondecotizaciones;


public class DetalleCotizacion {
    private int idDetalle;
    private Producto producto;
    private double precioUnitario;
    private int cantidad;

    public DetalleCotizacion() {
    }

    public DetalleCotizacion(int idDetalle, Producto producto, double precioUnitario, int cantidad) {
        this.idDetalle = idDetalle;
        this.producto = producto;
        this.precioUnitario = precioUnitario;
        this.cantidad = cantidad;
    }

    public int getIdDetalle() {
        return idDetalle;
    }

    public void setIdDetalle(int idDetalle) {
        this.idDetalle = idDetalle;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

   public double calcularsubTotal(double precioUnitario, int cantidad){
        return 0;
    }
}
