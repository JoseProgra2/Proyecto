/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestiondecotizaciones;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Jose Lopez
 */
public class GestionCotizacion {
    private Map<Integer, Cotizacion> cotiza;
       
    public GestionCotizacion() {
        this.cotiza = new HashMap();
    }

     public boolean agregar(Cotizacion a) {
        this.cotiza.put(a.getIdCotizacion(), a);
        return true;
    }

    public Cotizacion buscar(int id) {
        return this.cotiza.get(id);
    }

    public boolean eliminar(Cotizacion a) {
         return this.cotiza.remove(a.getIdCotizacion(), a);
    }

   
    public ArrayList<Cotizacion> obtener() {
        return  new ArrayList(this.cotiza.values());
        
    }
}
