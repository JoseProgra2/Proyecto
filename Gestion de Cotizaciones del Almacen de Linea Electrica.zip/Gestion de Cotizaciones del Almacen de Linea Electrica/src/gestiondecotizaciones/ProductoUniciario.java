/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestiondecotizaciones;

/**
 *
 * @author Jose Lopez
 */
public class ProductoUniciario extends Producto {
      private double preciouni;

    public ProductoUniciario() {
        super();
    }

    public ProductoUniciario(double preciouni, int idProducto, String nombre, String descripcion, double precio, int cantidad, Inventario productoinventario) {
        super(idProducto, nombre, descripcion, precio, cantidad, productoinventario);
        this.preciouni = preciouni;
    }
    public double getPreciouni() {
        return preciouni;
    }

    public void setPreciouni(double preciouni) {
        this.preciouni = preciouni;
    } 
    @Override
    public double calcularPrecio() {
        double precio=this.preciouni;
    return precio;
    }
}
