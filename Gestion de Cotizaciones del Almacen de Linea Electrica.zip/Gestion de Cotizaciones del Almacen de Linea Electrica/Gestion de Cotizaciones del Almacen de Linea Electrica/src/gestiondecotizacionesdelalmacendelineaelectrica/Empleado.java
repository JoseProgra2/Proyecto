/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestiondecotizacionesdelalmacendelineaelectrica;


public class Empleado extends Usuario{
   
    private String cargo;

    public Empleado() {
        super();
    }

    public Empleado(String cargo, int idUsuario, String nombre) {
        super(idUsuario, nombre);
        this.cargo = cargo;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    @Override
    public String toString() {
        return "Empleado{" + super.toString()+ "cargo=" + cargo + '}';
    }
    
    }

   
