/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestiondecotizaciones;
import java.util.ArrayList;
import java.time.LocalDate;
/**
 *
 * @author ESTUDIANTE
 */
public class Cotizacion {
    private int idCotizacion;
  private LocalDate fecha;
  private String estado;
  private double total;
  private ArrayList<Cliente> clientes;
  private ArrayList<DetalleCotizacion> Detalle;
  private Empleado empleado;
  private Almacen almacen;

    public Cotizacion() {
        this.clientes = new ArrayList();
        this.Detalle = new ArrayList();
    }

    public Cotizacion(int idCotizacion, LocalDate fecha, String estado, double total, Empleado empleado, Almacen almacen) {
        this();
        this.idCotizacion = idCotizacion;
        this.fecha = fecha;
        this.estado = estado;
        this.total = total;
        this.empleado = empleado;
        this.almacen = almacen;
    }
    public int getIdCotizacion() {
        return idCotizacion;
    }

    public void setIdCotizacion(int idCotizacion) {
        this.idCotizacion = idCotizacion;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    public ArrayList<DetalleCotizacion> getDetalle() {
        return Detalle;
    }

    public void setDetalle(ArrayList<DetalleCotizacion> Detalle) {
        this.Detalle = Detalle;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public Almacen getAlmacen() {
        return almacen;
    }

    public void setAlmacen(Almacen almacen) {
        this.almacen = almacen;
    }

    @Override
    public String toString() {
        return "Cotizacion{" + "idCotizacion=" + idCotizacion + ", fecha=" + fecha + ", estado=" + estado + ", total=" + total + ", clientes=" + clientes + ", Detalle=" + Detalle + ", empleado=" + empleado + ", almacen=" + almacen + '}';
    }
    
     public String generarCotizacion(Cotizacion a){
        
        return null;
        
    }
    public String actualizarEstado(String estado){
        
        return null;
        
    }
    public double calcularTotal(double a){
        
        return a;
        
    }
}

