/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestiondecotizaciones;


public class DetalleCotizacion {
    private int idDetalle;
    private Producto producto;
    private double precioUnitario;

    public DetalleCotizacion() {
    }

    public DetalleCotizacion(int idDetalle, Producto producto, double precioUnitario) {
        this.idDetalle = idDetalle;
        this.producto = producto;
        this.precioUnitario = precioUnitario;
    }

    public int getIdDetalle() {
        return idDetalle;
    }

    public void setIdDetalle(int idDetalle) {
        this.idDetalle = idDetalle;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    @Override
    public String toString() {
        return "DetalleCotizacion{" + "idDetalle=" + idDetalle + ", producto=" + producto + ", precioUnitario=" + precioUnitario + '}';
    }
   
    public double calcularsubTotal(double precioUnitario, int cantidad){
        return 0;
    }
}
