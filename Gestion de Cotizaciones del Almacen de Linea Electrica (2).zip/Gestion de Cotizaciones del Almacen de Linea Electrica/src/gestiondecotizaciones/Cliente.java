/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestiondecotizaciones;


public class Cliente {
    private int idCliente;
    private String nombre;
    private String direnccion;
    private double telefono;
    private Cotizacion cotizacion;

    public Cliente() {
    }

    public Cliente(int idCliente, String nombre, String direnccion, double telefono, Cotizacion cotizacion) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.direnccion = direnccion;
        this.telefono = telefono;
        this.cotizacion = cotizacion;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDirenccion() {
        return direnccion;
    }

    public void setDirenccion(String direnccion) {
        this.direnccion = direnccion;
    }

    public double getTelefono() {
        return telefono;
    }

    public void setTelefono(double telefono) {
        this.telefono = telefono;
    }

    public Cotizacion getCotizacion() {
        return cotizacion;
    }

    public void setCotizacion(Cotizacion cotizacion) {
        this.cotizacion = cotizacion;
    }

    @Override
    public String toString() {
        return "Cliente{" + "idCliente=" + idCliente + ", nombre=" + nombre + ", direnccion=" + direnccion + ", telefono=" + telefono + ", cotizacion=" + cotizacion + '}';
    }
    
}
